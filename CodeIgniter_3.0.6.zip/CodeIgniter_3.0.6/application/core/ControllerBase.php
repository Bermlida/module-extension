<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ControllerBase extends CI_Controller {

	/**
	 * @module-models = []
	 * @module-helpers = []
	 */
	public function __construct()
	{
		parent::__construct();
		$this->loadModules(__METHOD__);
	}

	private function loadModules($methodName)
	{		
		$methodReflection = new ReflectionMethod($methodName);
		$tests = $methodReflection->getDocComment();
		$tests = str_replace(["/**", " * ", " */"], "", $tests);
		preg_match("/@modules(\{(\s|\S)*\})/", $tests, $matches);
		//$tests = $matches
		print "<pre>"; var_dump($tests);
		print "<pre>"; var_dump($matches);
	}

}

/* End of file BaseController */
/* Location: ./application/controllers/BaseController */