<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ini_set("display_errors", "On");
error_reporting(E_ALL & ~E_NOTICE);

class Welcome extends CI_Controller {
	/**
	 * [$abc description]
	 * @var null
	 */
	private $abc = null;
	//private $test2 = new ControllerBase();

	/*
	 * @model:XXX,fff,dddd
	 */
	public function __construct()
	{
		parent::__construct();
		//$this->ddd = 555;
		//var_dump(get_declared_classes());
	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcomeP
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$aaa = new ControllerBase();
		//call_user_func_array(array(new ControllerBase(),'index'), array());
		//call_user_func_array('ControllerBase::index', array());
		//print "<pre>"; var_dump($test);
		//$test = new ReflectionClass($this);
		//var_dump($test);
		//var_dump($test->getProperty('ddd'));
		//print $this->ddd;
		$this->load->view('welcome_message');
	}
}
